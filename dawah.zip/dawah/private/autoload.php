<?php

require 'database.php';
require 'functions.php';
require 'url.php';