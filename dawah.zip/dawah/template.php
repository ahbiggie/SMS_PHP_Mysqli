<?php

require 'includes/header.inc.php';
require 'includes/sidebar.inc.php';

?>


	<?php require 'includes/footer.inc.php'; ?>